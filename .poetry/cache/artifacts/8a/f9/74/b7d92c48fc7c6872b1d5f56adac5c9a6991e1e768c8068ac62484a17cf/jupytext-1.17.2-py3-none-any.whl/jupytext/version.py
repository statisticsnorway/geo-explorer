"""Jupytext's version number"""

__version__ = "1.17.2"

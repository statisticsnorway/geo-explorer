"""Rebuild Sphinx documentation on changes, with hot reloading in the browser."""

__version__ = "2024.10.03"

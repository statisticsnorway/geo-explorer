BOOTSTRAP = (
    "https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
)
FONT_AWESOME = "https://use.fontawesome.com/releases/v6.7.2/css/all.css"

from __future__ import annotations

from deptry.reporters.json import JSONReporter
from deptry.reporters.text import TextReporter

__all__ = ("JSONReporter", "TextReporter")

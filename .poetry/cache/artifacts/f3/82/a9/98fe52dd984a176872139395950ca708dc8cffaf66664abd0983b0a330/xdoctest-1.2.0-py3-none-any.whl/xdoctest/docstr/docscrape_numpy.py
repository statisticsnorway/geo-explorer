# https://numpydoc.readthedocs.io/en/latest/format.html
